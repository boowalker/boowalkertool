# Turk-Sploit
Turk-Sploit , Türk Yapımı Ngrok destekli Phishing Toolu.

<h1>Termux Phishing Tool</h1>

<h2><strong>NOT:<i>Bu araç eğitim amaçlı hazırlandı.Aracın kullanımda meydana gelicek hiç bir şey sorumluluğumda değildir!</i><strong></h2>
	
	
<b>  Kullanımı</b>
<h3>
git clone https://github.com/yamanefkar/Turk-Sploit/<br>
cd Turk-Sploit/<br>
bash requirements.sh<br>
bash tst.sh<br>
<h3>        
